package br.com.fiap.application;

public class Listagem {
	public static void main(String[] args) {
		
		Client client = Client.create();
		WebResource resource =
		client.resource("http://localhost:8080/LojaApp_/rest/produto");
		ClientResponse response =
		resource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
		if (response.getStatus() == 200){
		ProdutoTO[] produtos = response.getEntity(ProdutoTO[].class);
		for (ProdutoTO produtoTO : produtos) {
		System.out.println(produtoTO.getTitulo());
		}
		}else{
		System.out.println("Erro - HTTP Status: " + response.getStatus());
		}

		
		}
	//Client client=Client.create();
	//WebResource resource=client.resource("htpp://localhost:8080/LojaApp_/rest/produto/1");
	//ClientResponse response=resource.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);
	//if(response.getStatus() == 200){
	//ProdutoTO produto=response.getEntity(ProdutoTO.class););
	//System.out.println(produto.getTitulo());
	//}else{
	//System.out.println("Erro - HTTP Status: " + response.getStatus());
	//}
}
