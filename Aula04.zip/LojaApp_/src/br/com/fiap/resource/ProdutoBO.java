package br.com.fiap.resource;

import java.util.List;

import br.com.fiap.resource.dao.ProdutoDAO;
import br.com.fiap.resource.to.ProdutoTO;

public class ProdutoBO {
	
	public List<ProdutoTO> listagemProduto(){	
		ProdutoDAO dao=new ProdutoDAO();
		return dao.select();
	}
	
	public ProdutoTO listagemProduto(int cod) {
		ProdutoDAO dao=new ProdutoDAO();
		return dao.select(cod);
	}
	public void cadastrar(ProdutoTO produto) {
		ProdutoDAO dao=new ProdutoDAO();
		dao.insert(produto);
	}
	
}
