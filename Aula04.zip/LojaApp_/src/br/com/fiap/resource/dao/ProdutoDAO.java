package br.com.fiap.resource.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.resource.to.ProdutoTO;

public class ProdutoDAO {

	public static List<ProdutoTO> listaProduto = null;

	public ProdutoDAO() {
		if (listaProduto == null) {
			listaProduto=new ArrayList<ProdutoTO>();
			
			ProdutoTO produto=new ProdutoTO();
			produto.setCodigo(1);
			produto.setPreco(2);
			produto.setQuantidade(3);
			produto.setTitulo("Produto 1");
			listaProduto.add(produto);
			
			produto=new ProdutoTO();
			produto.setCodigo(2);
			produto.setPreco(2);
			produto.setQuantidade(3);
			produto.setTitulo("Produto 2");
			listaProduto.add(produto);
			
			produto=new ProdutoTO();
			produto.setCodigo(3);
			produto.setPreco(2);
			produto.setQuantidade(3);
			produto.setTitulo("Produto 3");
			listaProduto.add(produto);
			
			produto=new ProdutoTO();
			produto.setCodigo(4);
			produto.setPreco(2);
			produto.setQuantidade(3);
			produto.setTitulo("Produto 4");
			listaProduto.add(produto);
			
		}
	}
	
	public List<ProdutoTO>select(){
		return listaProduto;
	}
	public ProdutoTO select(int id) {
		return listaProduto.get((id-1));
	}
	public void insert(ProdutoTO produto) {
		listaProduto.add(produto);
	}

}
